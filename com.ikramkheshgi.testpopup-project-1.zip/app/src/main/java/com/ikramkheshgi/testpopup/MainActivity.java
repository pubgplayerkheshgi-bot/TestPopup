package com.ikramkheshgi.testpopup;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40,50,40,40);

        TextView title = new TextView(this);
        title.setText("Test Popup");
        title.setTextSize(26);
        title.setTextColor(Color.BLACK);

        TextView info = new TextView(this);
        info.setText("Harmless test app for your Popup Detector.");
        info.setTextSize(16);
        info.setPadding(0,30,0,30);

        Button popup = new Button(this);
        popup.setText("SHOW TEST POPUP");

        box.addView(title);
        box.addView(info);
        box.addView(popup);
        setContentView(box);

        popup.setOnClickListener(v -> showPopup());

        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Allow popup permission")
                .setMessage("Allow Test Popup to display its harmless test popup over other apps.")
                .setPositiveButton("OPEN SETTINGS", (d,w) ->
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()))))
                .setNegativeButton("Cancel", null)
                .show();
        }
    }

    void showPopup() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Display over other apps first.", Toast.LENGTH_LONG).show();
            return;
        }

        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(35,25,35,25);
        p.setBackgroundColor(Color.WHITE);

        TextView t = new TextView(this);
        t.setText("TEST POPUP\nYour Popup Detector should detect this.");
        t.setTextColor(Color.BLACK);
        t.setTextSize(18);

        Button close = new Button(this);
        close.setText("CLOSE TEST");

        p.addView(t);
        p.addView(close);

        int type = Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);

        lp.gravity = Gravity.CENTER;
        wm.addView(p, lp);

        close.setOnClickListener(v -> wm.removeView(p));
    }
}
