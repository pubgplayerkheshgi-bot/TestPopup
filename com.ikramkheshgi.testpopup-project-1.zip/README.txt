Package: com.ikramkheshgi.testpopup
Purpose: harmless local test app for Popup Detector.
Permission: Display over other apps only.
